package com.smartcart.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartcart.dto.ApiResponse;
import com.smartcart.dto.RoutePoint;
import com.smartcart.dto.RouteProductRequest;
import com.smartcart.dto.RouteRequest;
import com.smartcart.dto.RouteResponse;


// ======================================================
// ROUTE CONTROLLER
// Xu ly API tao lo trinh mua sam
// ======================================================

@RestController
@RequestMapping("/api")
public class RouteController {


    // ==================================================
    // POST /api/generate-route
    // ==================================================

    @PostMapping("/generate-route")
    public ApiResponse<RouteResponse> generateRoute(
            @RequestBody RouteRequest request) {


        // ==================================================
        // KIEM TRA REQUEST
        // ==================================================

        if (request == null) {

            return new ApiResponse<>(
                    false,
                    "Du lieu yeu cau khong hop le",
                    null
            );
        }


        // ==================================================
        // KIEM TRA DIEM BAT DAU
        // ==================================================

        if (request.getStartPoint() == null) {

            return new ApiResponse<>(
                    false,
                    "Thieu diem bat dau",
                    null
            );
        }


        // ==================================================
        // KIEM TRA DANH SACH SAN PHAM
        // ==================================================

        if (request.getProducts() == null
                || request.getProducts().isEmpty()) {

            return new ApiResponse<>(
                    false,
                    "Danh sach san pham rong",
                    null
            );
        }


        // ==================================================
        // LAY DIEM BAT DAU
        // ==================================================

        RoutePoint startPoint =
                request.getStartPoint();


        // ==================================================
        // TAM THOI LAY SAN PHAM DAU TIEN
        //
        // Sau nay se thay bang route tu Python A* / TSP.
        // ==================================================

        RouteProductRequest firstProduct =
                request.getProducts().get(0);


        int destinationX =
                firstProduct.getXCoord();

        int destinationY =
                firstProduct.getYCoord();


        // ==================================================
        // TAO ROUTE MAU
        //
        // DAY CHUA PHAI A* / DIJKSTRA
        // ==================================================

        List<RoutePoint> routePoints =
                new ArrayList<>();


        // Diem xuat phat
        routePoints.add(
                new RoutePoint(
                        startPoint.getX(),
                        startPoint.getY()
                )
        );


        // Di len loi di ngang
        routePoints.add(
                new RoutePoint(
                        startPoint.getX(),
                        70
                )
        );


        // Di ngang toi X cua san pham
        routePoints.add(
                new RoutePoint(
                        destinationX,
                        70
                )
        );


        // Di den diem san pham
        routePoints.add(
                new RoutePoint(
                        destinationX,
                        destinationY
                )
        );


        // ==================================================
        // TAO RESPONSE
        // ==================================================

        RouteResponse routeResponse =
                new RouteResponse(
                        routePoints
                );


        // ==================================================
        // TRA KET QUA
        // ==================================================

        return new ApiResponse<>(
                true,
                "Tao du lieu lo trinh mau thanh cong",
                routeResponse
        );
    }
}