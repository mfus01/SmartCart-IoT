// ======================================================
// MAP MODULE
// Chiu trach nhiem ve ban do sieu thi tren Canvas
// ======================================================

const canvas =
    document.getElementById("mapCanvas");

const ctx =
    canvas.getContext("2d");


// ======================================================
// KICH THUOC LOGIC BAN DO
// Database dang dung toa do tu 0 -> 100
// ======================================================

const MAP_WIDTH = 100;
const MAP_HEIGHT = 100;


// ======================================================
// CHUYEN TOA DO LOGIC -> CANVAS
// ======================================================

function toCanvasX(x) {

    return (
        x / MAP_WIDTH
    ) * canvas.width;
}


function toCanvasY(y) {

    return (
        y / MAP_HEIGHT
    ) * canvas.height;
}


// ======================================================
// VE NEN
// ======================================================

function drawBackground() {

    ctx.clearRect(
        0,
        0,
        canvas.width,
        canvas.height
    );


    ctx.fillStyle =
        "#ffffff";

    ctx.fillRect(
        0,
        0,
        canvas.width,
        canvas.height
    );


    ctx.strokeStyle =
        "#b0bec5";

    ctx.lineWidth = 2;

    ctx.strokeRect(
        5,
        5,
        canvas.width - 10,
        canvas.height - 10
    );
}


// ======================================================
// VE KE HANG
// ======================================================

function drawShelf(
    label,
    x,
    y,
    width,
    height
) {

    ctx.fillStyle =
        "#90caf9";

    ctx.fillRect(
        x,
        y,
        width,
        height
    );


    ctx.strokeStyle =
        "#1565c0";

    ctx.lineWidth = 2;

    ctx.strokeRect(
        x,
        y,
        width,
        height
    );


    ctx.fillStyle =
        "#0d47a1";

    ctx.font =
        "bold 18px Arial";

    ctx.textAlign =
        "center";

    ctx.textBaseline =
        "middle";


    ctx.fillText(
        "Ke " + label,
        x + width / 2,
        y + height / 2
    );
}


// ======================================================
// VE DIEM TRUY CAP
// ======================================================

function drawAccessPoint(
    label,
    x,
    y
) {

    const canvasX =
        toCanvasX(x);

    const canvasY =
        toCanvasY(y);


    ctx.beginPath();

    ctx.arc(
        canvasX,
        canvasY,
        7,
        0,
        Math.PI * 2
    );


    ctx.fillStyle =
        "#d32f2f";

    ctx.fill();


    ctx.strokeStyle =
        "#ffffff";

    ctx.lineWidth = 2;

    ctx.stroke();


    ctx.fillStyle =
        "#333333";

    ctx.font =
        "13px Arial";

    ctx.textAlign =
        "left";

    ctx.textBaseline =
        "middle";


    ctx.fillText(
        label
        + " ("
        + x
        + ", "
        + y
        + ")",
        canvasX + 12,
        canvasY
    );
}


// ======================================================
// VE CUA VAO
// ======================================================

function drawEntrance() {

    const x = 40;

    const y =
        canvas.height - 55;

    const width = 130;
    const height = 40;


    ctx.fillStyle =
        "#c8e6c9";

    ctx.fillRect(
        x,
        y,
        width,
        height
    );


    ctx.strokeStyle =
        "#2e7d32";

    ctx.lineWidth = 2;

    ctx.strokeRect(
        x,
        y,
        width,
        height
    );


    ctx.fillStyle =
        "#1b5e20";

    ctx.font =
        "bold 16px Arial";

    ctx.textAlign =
        "center";

    ctx.textBaseline =
        "middle";


    ctx.fillText(
        "CUA VAO",
        x + width / 2,
        y + height / 2
    );
}


// ======================================================
// VE QUAY THANH TOAN
// ======================================================

function drawCheckout() {

    const width = 150;
    const height = 40;

    const x =
        canvas.width
        - width
        - 40;

    const y =
        canvas.height - 55;


    ctx.fillStyle =
        "#ffe0b2";

    ctx.fillRect(
        x,
        y,
        width,
        height
    );


    ctx.strokeStyle =
        "#ef6c00";

    ctx.lineWidth = 2;

    ctx.strokeRect(
        x,
        y,
        width,
        height
    );


    ctx.fillStyle =
        "#e65100";

    ctx.font =
        "bold 16px Arial";

    ctx.textAlign =
        "center";

    ctx.textBaseline =
        "middle";


    ctx.fillText(
        "THANH TOAN",
        x + width / 2,
        y + height / 2
    );
}


// ======================================================
// VE BAN DO SIEU THI
// ======================================================

export function drawSupermarketMap() {

    drawBackground();


    // KE A
    drawShelf(
        "A",
        70,
        100,
        220,
        55
    );


    // KE B
    drawShelf(
        "B",
        510,
        100,
        220,
        55
    );


    // KE C
    drawShelf(
        "C",
        70,
        300,
        220,
        55
    );


    // KE D
    drawShelf(
        "D",
        510,
        300,
        220,
        55
    );


    // DIEM TRUY CAP
    drawAccessPoint(
        "A",
        20,
        15
    );

    drawAccessPoint(
        "B",
        80,
        15
    );

    drawAccessPoint(
        "C",
        20,
        55
    );

    drawAccessPoint(
        "D",
        80,
        55
    );


    drawEntrance();

    drawCheckout();
}


// ======================================================
// VE DUONG DI
//
// HAM NAY KHONG TINH A* / DIJKSTRA.
// Chi nhan routePoints va ve len Canvas.
// ======================================================

export function drawRoute(
    routePoints
) {

    if (
        !routePoints
        || routePoints.length < 2
    ) {

        return;
    }


    ctx.beginPath();


    const startPoint =
        routePoints[0];


    ctx.moveTo(
        toCanvasX(startPoint.x),
        toCanvasY(startPoint.y)
    );


    for (
        let i = 1;
        i < routePoints.length;
        i++
    ) {

        const point =
            routePoints[i];


        ctx.lineTo(
            toCanvasX(point.x),
            toCanvasY(point.y)
        );
    }


    ctx.strokeStyle =
        "#7b1fa2";

    ctx.lineWidth = 5;


    ctx.setLineDash(
        [10, 8]
    );


    ctx.stroke();


    ctx.setLineDash([]);
}


// ======================================================
// LAM NOI BAT SAN PHAM
// ======================================================

export function highlightProductOnMap(
    product
) {

    // Xoa highlight cu
    drawSupermarketMap();


    // ==================================================
    // ROUTE TEST TAM THOI
    //
    // Sau nay se thay bang route
    // do module A* / Dijkstra cua Sinh vien B tra ve.
    // ==================================================

    const testRoute = [

        {
            x: 10,
            y: 90
        },

        {
            x: 10,
            y: 70
        },

        {
            x: product.xCoord,
            y: 70
        },

        {
            x: product.xCoord,
            y: product.yCoord
        }
    ];


    drawRoute(
        testRoute
    );


    const pointX =
        toCanvasX(
            product.xCoord
        );

    const pointY =
        toCanvasY(
            product.yCoord
        );


    // Khoanh diem truy cap
    ctx.beginPath();

    ctx.arc(
        pointX,
        pointY,
        14,
        0,
        Math.PI * 2
    );


    ctx.strokeStyle =
        "#ff9800";

    ctx.lineWidth = 5;

    ctx.stroke();


    // Vi tri cac ke
    const shelfPositions = {

        A: {
            x: 70,
            y: 100,
            width: 220,
            height: 55
        },

        B: {
            x: 510,
            y: 100,
            width: 220,
            height: 55
        },

        C: {
            x: 70,
            y: 300,
            width: 220,
            height: 55
        },

        D: {
            x: 510,
            y: 300,
            width: 220,
            height: 55
        }
    };


    const shelf =
        shelfPositions[
            product.shelfId
        ];


    // Highlight ke hang
    if (shelf) {

        ctx.strokeStyle =
            "#ff9800";

        ctx.lineWidth = 6;


        ctx.strokeRect(
            shelf.x - 5,
            shelf.y - 5,
            shelf.width + 10,
            shelf.height + 10
        );
    }


    // Hien ten san pham
    ctx.fillStyle =
        "#e65100";

    ctx.font =
        "bold 16px Arial";

    ctx.textAlign =
        "left";

    ctx.textBaseline =
        "bottom";


    ctx.fillText(
        product.name,
        pointX + 18,
        pointY - 10
    );
}