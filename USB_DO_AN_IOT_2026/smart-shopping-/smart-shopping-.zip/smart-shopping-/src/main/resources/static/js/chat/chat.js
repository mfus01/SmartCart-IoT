// ======================================================
// CHAT MODULE
// Quan ly giao dien tim san pham
// ======================================================

import {
    searchProducts
} from "../api/productApi.js";


import {
    highlightProductOnMap
} from "../map/map.js";


import {
    addToCart
} from "../cart/cart.js";


// ======================================================
// DOM
// ======================================================

const chatInput =
    document.getElementById(
        "chatInput"
    );


const sendButton =
    document.getElementById(
        "sendButton"
    );


const chatMessages =
    document.getElementById(
        "chatMessages"
    );


// ======================================================
// THEM TIN NHAN VAO CHAT
// ======================================================

function addChatMessage(
    message,
    type
) {

    const messageElement =
        document.createElement("p");


    messageElement.textContent =
        message;


    if (type === "user") {

        messageElement.style.background =
            "#1565c0";

        messageElement.style.color =
            "white";

    } else {

        messageElement.style.background =
            "#e3f2fd";

        messageElement.style.color =
            "#222";
    }


    chatMessages.appendChild(
        messageElement
    );


    chatMessages.scrollTop =
        chatMessages.scrollHeight;
}


// ======================================================
// HIEN KET QUA SAN PHAM
// ======================================================

function addProductResultMessage(
    product
) {

    const container =
        document.createElement(
            "div"
        );


    container.style.background =
        "#e3f2fd";

    container.style.padding =
        "12px";

    container.style.marginBottom =
        "10px";

    container.style.borderRadius =
        "8px";


    // ------------------------------
    // NOI DUNG SAN PHAM
    // ------------------------------

    const textElement =
        document.createElement(
            "div"
        );


    textElement.textContent =

        "Tim thay: "
        + product.name

        + " | Gia: "
        + product.price
            .toLocaleString(
                "vi-VN"
            )

        + " VND"

        + " | Ke "
        + product.shelfId

        + " | Toa do: ("
        + product.xCoord

        + ", "
        + product.yCoord

        + ")";


    // ------------------------------
    // NUT THEM VAO GIO
    // ------------------------------

    const addButton =
        document.createElement(
            "button"
        );


    addButton.textContent =
        "Them vao gio";


    addButton.style.marginTop =
        "10px";

    addButton.style.padding =
        "8px 12px";

    addButton.style.border =
        "none";

    addButton.style.borderRadius =
        "6px";

    addButton.style.background =
        "#2e7d32";

    addButton.style.color =
        "white";

    addButton.style.cursor =
        "pointer";


    addButton.addEventListener(
        "click",
        function() {

            addToCart(
                product
            );


            addChatMessage(
                "Da them "
                + product.name
                + " vao gio hang.",
                "bot"
            );
        }
    );


    container.appendChild(
        textElement
    );


    container.appendChild(
        addButton
    );


    chatMessages.appendChild(
        container
    );


    chatMessages.scrollTop =
        chatMessages.scrollHeight;
}


// ======================================================
// TIM SAN PHAM
// ======================================================

async function handleSearchProduct(
    keyword
) {

    try {

        const result =
            await searchProducts(
                keyword
            );


        if (!result.success) {

            addChatMessage(
                result.message,
                "bot"
            );

            return;
        }


        const products =
            result.data;


        // Highlight san pham dau tien
        if (
            products.length > 0
        ) {

            highlightProductOnMap(
                products[0]
            );
        }


        // Hien tat ca ket qua
        products.forEach(
            product => {

                addProductResultMessage(
                    product
                );
            }
        );

    } catch (error) {

        console.error(
            "Loi tim san pham:",
            error
        );


        addChatMessage(
            "Khong the ket noi den Backend.",
            "bot"
        );
    }
}


// ======================================================
// GUI TIN NHAN
// ======================================================

async function handleSendMessage() {

    const keyword =
        chatInput.value.trim();


    if (keyword === "") {

        return;
    }


    addChatMessage(
        keyword,
        "user"
    );


    chatInput.value = "";


    await handleSearchProduct(
        keyword
    );
}


// ======================================================
// KHOI DONG CHAT
// ======================================================

export function initChat() {

    sendButton.addEventListener(
        "click",
        handleSendMessage
    );


    chatInput.addEventListener(
        "keydown",
        function(event) {

            if (
                event.key === "Enter"
            ) {

                handleSendMessage();
            }
        }
    );
}